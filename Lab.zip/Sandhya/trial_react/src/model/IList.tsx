export default interface IList {
    id: number;
    product : string,
    price : number,
    payeeName : string,
    setDate : string
}